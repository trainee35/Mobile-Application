package com.tipcalculator.contractorcalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {


       double labor;
    double materialCost;
    double subtotal;
    double tax;
    double total;
    double taxRate = 0.05;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculatorCost();
    }

    private void calculatorCost() {
        Button calculate = findViewById(R.id.buttonCalculate);
        EditText etLabor = findViewById(R.id.editLabor);
        EditText etMaterialCost = findViewById(R.id.editMaterialCost);
        TextView tvSubtotal = findViewById(R.id.textSubtotal);
        TextView tvTax = findViewById(R.id.textTax);
        TextView tvTotal = findViewById(R.id.textTotal);

        calculate.setOnClickListener(v -> {
            // retrieves the cost values from the edit texts
            labor = Double.parseDouble(etLabor.getText().toString());
            materialCost = Double.parseDouble(etMaterialCost.getText().toString());

            subtotal = labor + materialCost; // calculate sub total
            tax = subtotal * taxRate ; // calculate tax amount
            total = subtotal + tax; // calculate total cost

            // round up to 1 or 2 decimal places
            subtotal = Math.round(subtotal * 100.0)/100.0;
            tax = Math.round(tax * 100.0)/100.0;
            total = Math.round(total * 100.0)/100.0;

            tvSubtotal.setText("" + subtotal); // displays the sub total
            tvTax.setText("" + tax); // displays the tax amount
            tvTotal.setText("" + total); // displays the total cost
        });
    }


  }
